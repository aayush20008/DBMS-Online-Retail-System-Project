import React from 'react'
import '../styles/footer.css'
const Footer = () => {
  return (
      <>

    <div className='footer_div'>
        Copyright 2022.   All Rights Reserved.
    </div>
      </>
  )
}

export default Footer